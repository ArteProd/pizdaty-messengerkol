from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Depends, HTTPException, status, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, or_, and_, func, desc, text
from sqlalchemy.orm import selectinload
from datetime import datetime
from typing import List
import jwt
import os
import json

import models
import schemas
import database
from websocket_manager import manager
from database import engine, AsyncSessionLocal
from auth import router as auth_router, get_current_user

# Создаем приложение
app = FastAPI(title="Pizdaty Messenger", version="1.0")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Подключаем роутер авторизации
app.include_router(auth_router)

# Подключаем статику
os.makedirs("static", exist_ok=True)
app.mount("/static", StaticFiles(directory="static"), name="static")

# ========== ФУНКЦИЯ СОЗДАНИЯ ИЗБРАННОГО ==========
async def ensure_saved_chat(user_id: int, db: AsyncSession):
    """Проверяет и создает чат 'Избранное' для пользователя"""
    result = await db.execute(
        select(models.Chat)
        .join(models.Chat.participants)
        .where(
            models.Chat.chat_type == 'saved',
            models.User.id == user_id
        )
    )
    saved_chat = result.scalar_one_or_none()
    
    if not saved_chat:
        saved_chat = models.Chat(
            name="Избранное",
            chat_type="saved",
            created_by=user_id
        )
        db.add(saved_chat)
        await db.flush()
        
        await db.execute(
            text("INSERT INTO chat_participants (user_id, chat_id) VALUES (:uid, :cid)"),
            {"uid": user_id, "cid": saved_chat.id}
        )
        
        welcome_message = models.Message(
            content="⭐ ИЗБРАННОЕ ⭐\n\nСЮДА МОЖНО СОХРАНЯТЬ:\n📝 Текстовые сообщения\n🔗 Ссылки и статьи\n📸 Фото и видео\n📍 Места и геолокации\n📎 Файлы и документы\n💡 Идеи и заметки\n\n👉 ПРОСТО ПИШИ СЮДА\n👈 ИЛИ ПЕРЕСЫЛАЙ ИЗ ЧАТОВ\n\n✨ ВСЁ СОХРАНИТСЯ!\n🚀 НИКУДА НЕ ПРОПАДЁТ!\n\n⚡️ УДАЧНОГО ИСПОЛЬЗОВАНИЯ! ⚡️",
            sender_id=user_id,
            chat_id=saved_chat.id,
            is_read=True
        )
        db.add(welcome_message)
        
        await db.commit()
        print(f"✅ Создан чат 'Избранное' для пользователя {user_id}")
    
    return saved_chat

# ========== СОЗДАНИЕ ТАБЛИЦ ==========
@app.on_event("startup")
async def startup():
    async with engine.begin() as conn:
        await conn.run_sync(models.Base.metadata.create_all)

# ========== ГЛАВНАЯ СТРАНИЦА ==========
@app.get("/", response_class=HTMLResponse)
async def root():
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Pizdaty Messenger</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
            <style>
            /* ===== CSS ПЕРЕМЕННЫЕ ДЛЯ ТЕМ ===== */
            :root {
                --bg-primary: #f5f7fb;
                --bg-secondary: #f8f9fa;
                --bg-white: #ffffff;
                --text-primary: #333333;
                --text-secondary: #666666;
                --text-muted: #999999;
                --border-color: #e0e0e0;
                --shadow-color: rgba(0,0,0,0.1);
                --input-bg: #f0f2f5;
                --message-received-bg: #ffffff;
                --message-sent-bg: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                --scrollbar-track: #f1f1f1;
                --scrollbar-thumb: #c1c1c1;
                --chat-item-hover: #e9ecef;
                --chat-item-active: #e3f2fd;
            }

            /* ТЁМНАЯ ТЕМА */
            [data-theme="dark"] {
                --bg-primary: #1a1a2e;
                --bg-secondary: #16213e;
                --bg-white: #0f0f23;
                --text-primary: #e0e0e0;
                --text-secondary: #b0b0b0;
                --text-muted: #707070;
                --border-color: #2a2a4a;
                --shadow-color: rgba(0,0,0,0.3);
                --input-bg: #1a1a2e;
                --message-received-bg: #16213e;
                --message-sent-bg: linear-gradient(135deg, #5a6fd6 0%, #6b4d9e 100%);
                --scrollbar-track: #1a1a2e;
                --scrollbar-thumb: #3a3a5a;
                --chat-item-hover: #1f1f3a;
                --chat-item-active: #1a3a5a;
            }

            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            }
            
            body {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                display: flex;
                justify-content: center;
                align-items: center;
                padding: 10px;
            }
            
            body[data-theme="dark"] {
                background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            }
            
            .auth-container {
                background: var(--bg-white);
                border-radius: 20px;
                padding: clamp(20px, 5vw, 40px);
                width: 100%;
                max-width: 400px;
                box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                animation: slideUp 0.5s ease;
                margin: auto;
            }
            
            .messenger-container {
                background: var(--bg-white);
                border-radius: 20px;
                width: 100%;
                height: 95vh;
                max-height: 900px;
                display: flex;
                flex-direction: row;
                overflow: hidden;
                box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                display: none;
            }
            
            @media (max-width: 768px) {
                .messenger-container {
                    height: 100vh;
                    border-radius: 0;
                    max-height: none;
                }
                body {
                    padding: 0;
                }
            }
            
            @media (max-width: 480px) {
                .messenger-container {
                    flex-direction: column;
                }
                .sidebar {
                    width: 100% !important;
                    height: auto;
                    max-height: 40vh;
                }
                .chat-main {
                    height: 60vh;
                }
                .message {
                    max-width: 85% !important;
                }
            }
            
            @keyframes slideUp {
                from { opacity: 0; transform: translateY(20px); }
                to { opacity: 1; transform: translateY(0); }
            }
            
            h1 { 
                font-size: clamp(20px, 5vw, 28px);
                color: var(--text-primary);
                margin-bottom: 20px;
            }
            
            input, textarea {
                width: 100%;
                padding: clamp(12px, 3vw, 15px);
                margin: 8px 0;
                border: 2px solid var(--border-color);
                border-radius: 10px;
                font-size: clamp(14px, 3vw, 16px);
                transition: border 0.3s;
                background: var(--input-bg);
                color: var(--text-primary);
            }

            input:focus, textarea:focus {
                outline: none;
                border-color: #667eea;
            }

            input::placeholder, textarea::placeholder {
                color: var(--text-muted);
            }
            
            button {
                width: 100%;
                padding: clamp(12px, 3vw, 15px);
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                border: none;
                border-radius: 10px;
                font-size: clamp(14px, 3vw, 16px);
                font-weight: bold;
                cursor: pointer;
                margin: 8px 0;
                transition: transform 0.2s;
            }
            
            button:hover {
                transform: translateY(-2px);
            }
            
            .toggle-btn {
                background: transparent;
                color: #667eea;
                border: 2px solid #667eea;
                margin-top: 20px;
            }
            
            .error {
                color: #e74c3c;
                margin: 10px 0;
            }
            
            /* Стили мессенджера */
            .sidebar {
                width: 350px;
                background: var(--bg-secondary);
                border-right: 1px solid var(--border-color);
                display: flex;
                flex-direction: column;
                height: 100%;
            }
            
            .profile {
                padding: 20px;
                background: var(--bg-white);
                border-bottom: 1px solid var(--border-color);
                display: flex;
                align-items: center;
                gap: 12px;
            }
            
            .avatar {
                width: 50px;
                height: 50px;
                border-radius: 50%;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                font-weight: bold;
                font-size: 20px;
                flex-shrink: 0;
            }
            
            .user-info {
                flex: 1;
                min-width: 0;
            }
            
            .user-info h3 {
                color: var(--text-primary);
                margin-bottom: 5px;
                font-size: 16px;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            
            .status-container {
                display: flex;
                align-items: center;
                gap: 5px;
            }
            
            .user-status {
                display: inline-block;
                width: 10px;
                height: 10px;
                border-radius: 50%;
            }
            
            .status-online {
                background: #2ecc71;
                box-shadow: 0 0 5px #2ecc71;
            }
            
            .status-offline {
                background: #95a5a6;
            }
            
            .status-text {
                font-size: 12px;
                color: var(--text-secondary);
            }
            
            .search {
                padding: 15px;
                background: var(--bg-white);
                border-bottom: 1px solid var(--border-color);
            }
            
            .search input {
                width: 100%;
                padding: 12px 15px;
                background: var(--input-bg);
                border: none;
                border-radius: 25px;
                font-size: 14px;
                margin: 0;
            }
            
            .chats-list {
                flex: 1;
                overflow-y: auto;
                padding: 10px;
            }
            
            .chat-item {
                display: flex;
                align-items: center;
                padding: 12px 15px;
                border-radius: 12px;
                cursor: pointer;
                transition: all 0.2s;
                margin-bottom: 5px;
            }
            
            .chat-item:hover {
                background: var(--chat-item-hover);
            }
            
            .chat-item.active {
                background: var(--chat-item-active);
            }
            
            .chat-avatar {
                width: 45px;
                height: 45px;
                border-radius: 50%;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                font-weight: bold;
                font-size: 18px;
                margin-right: 12px;
                flex-shrink: 0;
            }
            
            .chat-info {
                flex: 1;
                min-width: 0;
            }
            
            .chat-name {
                font-weight: 600;
                color: var(--text-primary);
                margin-bottom: 4px;
                font-size: 15px;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            
            .last-message {
                font-size: 13px;
                color: var(--text-secondary);
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            
            .chat-time {
                font-size: 11px;
                color: var(--text-muted);
                margin-left: 8px;
                white-space: nowrap;
            }
            
            .chat-main {
                flex: 1;
                display: flex;
                flex-direction: column;
                background: var(--bg-white);
                min-width: 0;
            }
            
            .chat-header {
                padding: 20px;
                background: var(--bg-white);
                border-bottom: 1px solid var(--border-color);
                display: flex;
                align-items: center;
                gap: 12px;
            }
            
            .messages-container {
                flex: 1;
                overflow-y: auto;
                padding: 20px;
                background: var(--bg-primary);
                display: flex;
                flex-direction: column;
            }
            
            .message {
                max-width: 65%;
                margin-bottom: 15px;
                padding: 12px 16px;
                border-radius: 18px;
                word-wrap: break-word;
                animation: fadeIn 0.2s ease;
                font-size: 15px;
            }
            
            @keyframes fadeIn {
                from { opacity: 0; transform: translateY(5px); }
                to { opacity: 1; transform: translateY(0); }
            }
            
            .message.sent {
                background: var(--message-sent-bg);
                color: white;
                align-self: flex-end;
                border-bottom-right-radius: 4px;
            }
            
            .message.received {
                background: var(--message-received-bg);
                color: var(--text-primary);
                align-self: flex-start;
                box-shadow: 0 2px 5px var(--shadow-color);
                border-bottom-left-radius: 4px;
            }
            
            .message-info {
                font-size: 11px;
                margin-top: 5px;
                opacity: 0.8;
                display: flex;
                justify-content: flex-end;
                gap: 5px;
                color: inherit;
            }
            
            .message-input {
                padding: 20px;
                background: var(--bg-white);
                border-top: 1px solid var(--border-color);
                display: flex;
                gap: 10px;
            }
            
            .message-input input {
                flex: 1;
                margin: 0;
                padding: 15px 20px;
                border: 2px solid var(--border-color);
                border-radius: 25px;
                font-size: 15px;
                min-width: 0;
                background: var(--input-bg);
                color: var(--text-primary);
            }
            
            .message-input button {
                width: auto;
                padding: 0 30px;
                margin: 0;
                border-radius: 25px;
                font-size: 15px;
                white-space: nowrap;
                flex-shrink: 0;
            }
            
            .empty-state {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                height: 100%;
                color: var(--text-muted);
                font-size: 14px;
                text-align: center;
                padding: 20px;
            }
            
            ::-webkit-scrollbar {
                width: 6px;
            }
            
            ::-webkit-scrollbar-track {
                background: var(--scrollbar-track);
            }
            
            ::-webkit-scrollbar-thumb {
                background: var(--scrollbar-thumb);
                border-radius: 3px;
            }
            
            .chat-item[data-chat-type="saved"] .chat-avatar {
                background: linear-gradient(135deg, #f1c40f, #f39c12) !important;
            }
            /* ===== ИЗБРАННОЕ - ПРЕМИУМ СТИЛИ ===== */

            /* Стиль для чата "Избранное" в списке */
            .chat-item[data-chat-type="saved"] {
                background: linear-gradient(135deg, #fff9e6, #fff);
                border-left: 4px solid #f1c40f;
                position: relative;
                overflow: hidden;
            }

            .chat-item[data-chat-type="saved"]::before {
                content: '⭐⭐⭐';
                position: absolute;
                right: -10px;
                top: -10px;
                font-size: 30px;
                opacity: 0.1;
                transform: rotate(15deg);
            }

            .chat-item[data-chat-type="saved"] .chat-avatar {
                background: linear-gradient(135deg, #f1c40f, #f39c12) !important;
                box-shadow: 0 0 15px rgba(241, 196, 15, 0.5);
                animation: starPulse 3s infinite;
            }

            .chat-item[data-chat-type="saved"] .chat-name {
                color: #f39c12;
                font-weight: 700;
                text-shadow: 0 0 5px rgba(241, 196, 15, 0.3);
            }

            .chat-item[data-chat-type="saved"]:hover {
                background: #fff3d6;
                transform: translateX(5px);
            }

            /* Анимация звезды */
            @keyframes starPulse {
                0% { box-shadow: 0 0 0 0 rgba(241, 196, 15, 0.4); }
                70% { box-shadow: 0 0 0 10px rgba(241, 196, 15, 0); }
                100% { box-shadow: 0 0 0 0 rgba(241, 196, 15, 0); }
            }

            /* ===== ОСОБЫЙ ФОН ДЛЯ ЧАТА ИЗБРАННОЕ ===== */
            .chat-main[data-chat-type="saved"] {
                background: linear-gradient(135deg, #fffcf0, #fff5e6);
            }

            /* Список в приветствии */
            .message.saved-welcome div:nth-child(1) {
                font-weight: bold;
                color: #c27e0e !important;
            }

            .chat-main[data-chat-type="saved"] .messages-container {
                background: #fff5eb;
            }

            .chat-main[data-chat-type="saved"] .messages-container::before {
                content: '⭐⭐⭐⭐⭐';
                position: absolute;
                bottom: 10px;
                right: 20px;
                font-size: 60px;
                opacity: 0.05;
                white-space: nowrap;
                transform: rotate(-10deg);
                pointer-events: none;
            }

            /* Заголовок чата Избранное */
            .chat-main[data-chat-type="saved"] .chat-header {
                background: linear-gradient(135deg, #f1c40f20, #f39c1220);
                border-bottom: 2px solid #f1c40f;
            }

            .chat-main[data-chat-type="saved"] .chat-header .avatar {
                background: linear-gradient(135deg, #f1c40f, #f39c12) !important;
                font-size: 24px;
                animation: starSpin 10s linear infinite;
            }

            @keyframes starSpin {
                from { transform: rotate(0deg); }
                to { transform: rotate(360deg); }
            }

            .chat-main[data-chat-type="saved"] .chat-header .chat-name {
                color: #f39c12;
                font-size: 20px;
                font-weight: 700;
                text-shadow: 0 0 10px rgba(241, 196, 15, 0.3);
            }

            /* Сообщения в Избранном */
            .chat-main[data-chat-type="saved"] .message.sent {
                background: linear-gradient(135deg, #f1c40f, #f39c12);
                color: white;  /* БЕЛЫЙ ТОЛЬКО НА ЗОЛОТОМ ФОНЕ */
            }

            .chat-main[data-chat-type="saved"] .message.sent::after {
                content: '⭐';
                position: absolute;
                right: 5px;
                bottom: 5px;
                font-size: 16px;
                opacity: 0.3;
            }

            .chat-main[data-chat-type="saved"] .message.received {
                background: white;
                color: #333;  /* ТЕМНЫЙ ТЕКСТ НА БЕЛОМ */
                border: 1px solid #f1c40f;
            }

            /* Специальное приветственное сообщение */
            .message.saved-welcome {
                background: #fff9e6 !important;  /* СВЕТЛЫЙ ФОН */
                border: 2px solid #f1c40f !important;
                border-radius: 15px !important;
                padding: 20px !important;
                color: #333 !important;  /* ТЕМНЫЙ ТЕКСТ */
                font-size: 15px !important;
                line-height: 1.6 !important;
                max-width: 90% !important;
                margin: 20px auto !important;
            }

            @keyframes starBounce {
                0%, 100% { transform: scale(1); }
                50% { transform: scale(1.2); }
            }

            @keyframes welcomeGlow {
                0% { box-shadow: 0 5px 20px rgba(241, 196, 15, 0.1); }
                50% { box-shadow: 0 5px 30px rgba(241, 196, 15, 0.3); }
                100% { box-shadow: 0 5px 20px rgba(241, 196, 15, 0.1); }
            }

            .message.saved-welcome .message-info {
                color: #f39c12 !important;
                margin-top: 10px;
                border-top: 1px solid #f1c40f;
                padding-top: 8px;
            }

            /* Красивое форматирование списка в приветствии */
            .message.saved-welcome div {
                color: #333 !important;  /* ТЕМНЫЙ ТЕКСТ */
            }

            .message.saved-welcome div:first-child {
                text-align: center;
                font-size: 20px;
                font-weight: bold;
                padding-left: 0;
            }
            /* ========== ДОПОЛНИТЕЛЬНЫЕ СТИЛИ ДЛЯ ТЁМНОЙ ТЕМЫ ========== */
            [data-theme="dark"] {
                background: #0f0f1a !important;
            }
            
            [data-theme="dark"] .auth-container,
            [data-theme="dark"] #authContainer {
                background: #1a1a2e !important;
            }
            
            [data-theme="dark"] .auth-container h1,
            [data-theme="dark"] #authContainer h1 {
                color: #e0e0e0 !important;
            }
            
            [data-theme="dark"] .auth-container input,
            [data-theme="dark"] #authContainer input {
                background: #16213e !important;
                border: 2px solid #2d2d44 !important;
                color: #e0e0e0 !important;
            }
            
            [data-theme="dark"] .auth-container input::placeholder,
            [data-theme="dark"] #authContainer input::placeholder {
                color: #666 !important;
            }
            
            [data-theme="dark"] .auth-container h3 {
                color: #e0e0e0 !important;
            }
            
            [data-theme="dark"] .auth-container hr {
                border-color: #2d2d44 !important;
            }
            
            [data-theme="dark"] .messenger-container {
                background: #0f0f1a !important;
            }
            
            [data-theme="dark"] .sidebar {
                background: #1a1a2e !important;
                border-right: 1px solid #2d2d44 !important;
            }
            
            [data-theme="dark"] .profile {
                background: #16213e !important;
                border-bottom: 1px solid #2d2d44 !important;
            }
            
            [data-theme="dark"] .user-info h3,
            [data-theme="dark"] .chat-name {
                color: #e0e0e0 !important;
            }
            
            [data-theme="dark"] .status-text,
            [data-theme="dark"] .last-message {
                color: #a0a0a0 !important;
            }
            
            [data-theme="dark"] .search {
                background: #16213e !important;
                border-bottom: 1px solid #2d2d44 !important;
            }
            
            [data-theme="dark"] .search input {
                background: #1a1a2e !important;
                color: #e0e0e0 !important;
            }
            
            [data-theme="dark"] .chats-list {
                background: #1a1a2e !important;
            }
            
            [data-theme="dark"] .chat-item {
                background: #1a1a2e !important;
            }
            
            [data-theme="dark"] .chat-item:hover {
                background: #16213e !important;
            }
            
            [data-theme="dark"] .chat-item.active {
                background: #1a3a5a !important;
            }
            
            [data-theme="dark"] .chat-time {
                color: #666 !important;
            }
            
            [data-theme="dark"] .chat-main {
                background: #0f0f1a !important;
            }
            
            [data-theme="dark"] .chat-header {
                background: #16213e !important;
                border-bottom: 1px solid #2d2d44 !important;
            }
            
            [data-theme="dark"] .messages-container {
                background: #0f0f1a !important;
            }
            
            [data-theme="dark"] .message-input {
                background: #16213e !important;
                border-top: 1px solid #2d2d44 !important;
            }
            
            [data-theme="dark"] .message-input input {
                background: #1a1a2e !important;
                color: #e0e0e0 !important;
                border-color: #2d2d44 !important;
            }
            
            [data-theme="dark"] .message-input input::placeholder {
                color: #666 !important;
            }
            
            [data-theme="dark"] .message.received {
                background: #16213e !important;
                color: #e0e0e0 !important;
            }
            
            /* Кнопки внизу сайдбара - Настройки и Выйти */
            [data-theme="dark"] div[style*="border-top: 1px solid"] {
                background: #16213e !important;
                border-top: 1px solid #2d2d44 !important;
            }
            
            [data-theme="dark"] div[style*="border-top: 1px solid"] button {
                background: #1a1a2e !important;
                border: 1px solid #2d2d44 !important;
                color: #e0e0e0 !important;
            }
            
            [data-theme="dark"] div[style*="border-top: 1px solid"] button:last-child {
                background: #c0392b !important;
                border: none !important;
                color: white !important;
            }
            
            /* Избранное в списке чатов */
            [data-theme="dark"] .chat-item[data-chat-type="saved"] {
                background: linear-gradient(135deg, #1a1a2e, #16213e) !important;
                border-left: 4px solid #f1c40f !important;
            }
            
            [data-theme="dark"] .chat-item[data-chat-type="saved"] .chat-avatar {
                background: linear-gradient(135deg, #f1c40f, #f39c12) !important;
            }
            
            [data-theme="dark"] .chat-item[data-chat-type="saved"] .chat-name {
                color: #f1c40f !important;
            }
            
            [data-theme="dark"] .chat-item[data-chat-type="saved"]:hover {
                background: #1f1f3a !important;
            }
            
            /* Чат Избранное */
            [data-theme="dark"] .chat-main[data-chat-type="saved"] {
                background: linear-gradient(135deg, #0f0f1a, #1a1a2e) !important;
            }
            
            [data-theme="dark"] .chat-main[data-chat-type="saved"] .messages-container {
                background: #0f0f1a !important;
            }
            
            [data-theme="dark"] .chat-main[data-chat-type="saved"] .chat-header {
                background: linear-gradient(135deg, #1a1a2e, #16213e) !important;
                border-bottom: 2px solid #f1c40f !important;
            }
            
            [data-theme="dark"] .chat-main[data-chat-type="saved"] .chat-header .chat-name {
                color: #f1c40f !important;
            }
            
            [data-theme="dark"] .chat-main[data-chat-type="saved"] .chat-header .avatar {
                background: linear-gradient(135deg, #f1c40f, #f39c12) !important;
            }
            
            [data-theme="dark"] .chat-main[data-chat-type="saved"] .message.received {
                background: #16213e !important;
                color: #e0e0e0 !important;
                border: 1px solid #2d2d44 !important;
            }
            
            [data-theme="dark"] .chat-main[data-chat-type="saved"] .message.sent {
                background: linear-gradient(135deg, #f1c40f, #f39c12) !important;
                color: white !important;
            }
            
            [data-theme="dark"] .chat-main[data-chat-type="saved"] .message.saved-welcome {
                background: #1a1a2e !important;
                border: 2px solid #f1c40f !important;
                color: #e0e0e0 !important;
            }
            
            [data-theme="dark"] .chat-main[data-chat-type="saved"] .message.saved-welcome div {
                color: #e0e0e0 !important;
            }
            
            [data-theme="dark"] .chat-main[data-chat-type="saved"] .message.saved-welcome div:first-child {
                color: #f1c40f !important;
            }
            
            /* Модальное окно настроек */
            [data-theme="dark"] div[style*="border-radius: 20px"] {
                background: #1a1a2e !important;
            }
            
            [data-theme="dark"] div[style*="border-radius: 20px"] h2 {
                color: #e0e0e0 !important;
            }
            
            [data-theme="dark"] div[style*="border-radius: 20px"] label {
                color: #a0a0a0 !important;
            }
            
            [data-theme="dark"] div[style*="border-radius: 20px"] input,
            [data-theme="dark"] div[style*="border-radius: 20px"] textarea {
                background: #16213e !important;
                border: 2px solid #2d2d44 !important;
                color: #e0e0e0 !important;
            }
            
            [data-theme="dark"] div[style*="border-radius: 20px"] button {
                background: #16213e !important;
                color: #e0e0e0 !important;
                border: 1px solid #2d2d44 !important;
            }
            
            [data-theme="dark"] div[style*="border-radius: 20px"] button:hover {
                background: #1a1a2e !important;
            }
            
            /* Оверлей модального окна */
            [data-theme="dark"] div[style*="position: fixed"] {
                background: rgba(0,0,0,0.7) !important;
            }
            
            /* Скроллбар */
            [data-theme="dark"] ::-webkit-scrollbar {
                width: 6px;
            }
            
            [data-theme="dark"] ::-webkit-scrollbar-track {
                background: #1a1a2e !important;
            }
            
            [data-theme="dark"] ::-webkit-scrollbar-thumb {
                background: #3a3a5a !important;
                border-radius: 3px;
            }
        </style>
    </head>
    <body>
        <div class="auth-container" id="authContainer">
            <h1>Пиздатый Мессенджер</h1>
            <div id="authError" class="error" style="color: red; font-size: 14px;"></div>
            
            <input type="text" id="loginUsername" placeholder="Имя пользователя">
            <input type="password" id="loginPassword" placeholder="Пароль">
            
            <button id="loginBtn">🚪 Войти</button>
            
            <hr style="margin: 20px 0;">
            
            <h3>Регистрация</h3>
            <input type="text" id="regUsername" placeholder="Имя пользователя">
            <input type="email" id="regEmail" placeholder="Email">
            <input type="password" id="regPassword" placeholder="Пароль">
            <input type="password" id="regPasswordConfirm" placeholder="Повторите пароль">
            
            <button id="registerBtn" style="background: #28a745;">📝 Зарегистрироваться</button>
        </div>
        
        <div class="messenger-container" id="messengerContainer">
            <div class="sidebar">
                <div class="profile">
                    <div class="avatar" id="userAvatar">U</div>
                    <div class="user-info">
                        <h3 id="userName">User</h3>
                        <div class="status-container">
                            <span class="user-status status-online" id="userStatusDot"></span>
                            <span class="status-text" id="userStatusText">В сети</span>
                        </div>
                    </div>
                </div>
                
                <div class="search">
                    <input type="text" id="searchInput" placeholder="Поиск или новый чат...">
                </div>
                
                <div class="chats-list" id="chatsList"></div>
                
                <div style="padding: 15px; border-top: 1px solid #e0e0e0; background: white;">
                    <button onclick="openSettings()" style="
                        width: 100%;
                        padding: 12px;
                        background: #f0f2f5;
                        border: 1px solid #e0e0e0;
                        color: #333;
                        border-radius: 10px;
                        cursor: pointer;
                        font-size: 14px;
                        font-weight: 500;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        gap: 8px;
                        margin-bottom: 10px;
                    ">
                        ⚙️ Настройки
                    </button>
                    
                    <button onclick="logout()" style="
                        width: 100%;
                        padding: 12px;
                        background: #ff4757;
                        border: none;
                        color: white;
                        border-radius: 10px;
                        cursor: pointer;
                        font-size: 14px;
                        font-weight: 500;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        gap: 8px;
                    ">
                        🚪 Выйти
                    </button>
                </div>
            </div>
            
            <div class="chat-main">
                <div class="chat-header">
                    <div class="avatar" id="chatAvatar">G</div>
                    <div class="user-info">
                        <h3 id="chatName">Выберите чат</h3>
                        <div class="status-container" id="chatStatus"></div>
                    </div>
                </div>
                
                <div class="messages-container" id="messagesContainer"></div>
                
                <div class="message-input">
                    <input type="text" id="messageText" placeholder="Написать сообщение..." disabled>
                    <button id="sendMessageBtn" disabled>Отправить</button>
                </div>
            </div>
        </div>
        
        <script>
            // ========== ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ ==========
            let accessToken = localStorage.getItem('accessToken');
            let refreshToken = localStorage.getItem('refreshToken');
            let currentUser = null;
            let ws = null;
            let currentChatId = localStorage.getItem('currentChatId');
            let isAuthenticating = false;

            // ========== ТЕМА ==========
            function applyTheme(darkMode) {
                if (darkMode) {
                    document.documentElement.setAttribute('data-theme', 'dark');
                    document.body.setAttribute('data-theme', 'dark');
                } else {
                    document.documentElement.removeAttribute('data-theme');
                    document.body.removeAttribute('data-theme');
                }
            }

            // При загрузке страницы применяем сохраненную тему
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') {
                applyTheme(true);
            }

            window.addEventListener('beforeunload', function() {
                // Если это не выход из аккаунта, а просто перезагрузка
                if (!isLoggingOut && ws) {
                    ws.close();
                }
            });

            // ========== ПРИ ЗАГРУЗКЕ СТРАНИЦЫ ==========
            document.addEventListener('DOMContentLoaded', async () => {
                console.log('Страница загружена. Токены:', accessToken ? 'есть' : 'нет');
                
                if (accessToken && refreshToken) {
                    document.getElementById('authContainer').style.display = 'none';
                    document.getElementById('messengerContainer').style.display = 'flex';
                    await attemptLogin();
                }
            });

            // ========== АВТОМАТИЧЕСКИЙ ВХОД ==========
            async function attemptLogin() {
                if (isAuthenticating) return;
                isAuthenticating = true;
                
                try {
                    const response = await fetch('/api/auth/me', {
                        headers: {'Authorization': `Bearer ${accessToken}`}
                    });
                    
                    if (!response.ok) {
                        throw new Error('Ошибка авторизации');
                    }
                    
                    currentUser = await response.json();
                    
                    document.getElementById('userName').textContent = currentUser.username;
                    document.getElementById('userAvatar').textContent = currentUser.username[0].toUpperCase();
                    
                    // Сбрасываем флаг выхода
                    isLoggingOut = false;
                    
                    connectWebSocket();
                    await loadChats();
                    
                    if (currentChatId) {
                        await selectChat(parseInt(currentChatId));
                    }
                    
                } catch (error) {
                    console.error('Ошибка входа:', error);
                    logout();
                } finally {
                    isAuthenticating = false;
                }
            }

            // ========== ОБНОВЛЕНИЕ ТОКЕНА ==========
            async function refreshAccessToken() {
                if (!refreshToken) return false;
                
                try {
                    const response = await fetch('/api/auth/refresh', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({refresh_token: refreshToken})
                    });
                    
                    if (response.ok) {
                        const data = await response.json();
                        accessToken = data.access_token;
                        localStorage.setItem('accessToken', accessToken);
                        return true;
                    }
                } catch (e) {}
                return false;
            }

            // ========== ВХОД ==========
            document.getElementById('loginBtn').onclick = async () => {
                const username = document.getElementById('loginUsername').value.trim();
                const password = document.getElementById('loginPassword').value;
                const errorEl = document.getElementById('authError');
                errorEl.textContent = '';
                
                if (!username || !password) {
                    errorEl.textContent = 'Введите логин и пароль';
                    return;
                }
                
                try {
                    const response = await fetch('/api/auth/login', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({username, password})
                    });
                    
                    const data = await response.json();
                    
                    if (!response.ok) {
                        throw new Error(data.detail || 'Ошибка входа');
                    }
                    
                    accessToken = data.access_token;
                    refreshToken = data.refresh_token;
                    localStorage.setItem('accessToken', accessToken);
                    localStorage.setItem('refreshToken', refreshToken);
                    
                    location.reload();
                    
                } catch (error) {
                    errorEl.textContent = error.message;
                }
            };

            // ========== РЕГИСТРАЦИЯ ==========
            document.getElementById('registerBtn').onclick = async () => {
                const username = document.getElementById('regUsername').value.trim();
                const email = document.getElementById('regEmail').value.trim();
                const password = document.getElementById('regPassword').value;
                const passwordConfirm = document.getElementById('regPasswordConfirm').value;
                const errorEl = document.getElementById('authError');
                errorEl.textContent = '';
                
                if (!username || !email || !password || !passwordConfirm) {
                    errorEl.textContent = 'Заполните все поля';
                    return;
                }
                
                if (password !== passwordConfirm) {
                    errorEl.textContent = 'Пароли не совпадают';
                    return;
                }
                
                try {
                    const response = await fetch('/api/auth/register', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({username, email, password})
                    });
                    
                    const data = await response.json();
                    
                    if (!response.ok) {
                        throw new Error(data.detail || 'Ошибка регистрации');
                    }
                    
                    errorEl.style.color = 'green';
                    errorEl.textContent = 'Регистрация успешна! Теперь войдите.';
                    
                    document.getElementById('loginUsername').value = username;
                    
                } catch (error) {
                    errorEl.textContent = error.message;
                }
            };

            // ========== СТАТУСЫ ==========
            function updateMyStatus(isOnline) {
                const dot = document.getElementById('userStatusDot');
                const text = document.getElementById('userStatusText');
                
                if (!dot || !text) return;
                
                // Проверяем, не вышли ли мы из аккаунта
                if (!accessToken || !currentUser) {
                    dot.className = 'user-status status-offline';
                    text.textContent = 'Не в сети';
                    return;
                }
                
                dot.className = 'user-status ' + (isOnline ? 'status-online' : 'status-offline');
                text.textContent = isOnline ? 'В сети' : 'Не в сети';
            }

            // Часовой пояс МСК (UTC+3)
            const MSK_OFFSET = 3 * 60 * 60 * 1000;
            
            function toMSK(date) {
                return new Date(date.getTime() + MSK_OFFSET);
            }
            
            function formatLastSeen(dateStr) {
                // Сервер возвращает UTC время, парсим как UTC
                const lastSeenUTC = new Date(dateStr + 'Z');  // Явно добавляем Z для UTC
                const now = new Date();
                const diff = now - lastSeenUTC;
                
                if (diff < 60000) return 'только что';
                if (diff < 3600000) {
                    const minutes = Math.floor(diff / 60000);
                    return `${minutes} ${minutes === 1 ? 'минуту' : 'минуты'} назад`;
                }
                if (diff < 86400000) {
                    const hours = Math.floor(diff / 3600000);
                    return `${hours} ${hours === 1 ? 'час' : 'часа'} назад`;
                }
                return lastSeenUTC.toLocaleDateString('ru-RU');
            }

            function updateChatHeaderStatus(user) {
                const container = document.getElementById('chatStatus');
                if (!container) return;
                
                // Если статус скрыт - показываем "Был недавно"
                if (user.is_online === false || user.is_online === undefined) {
                    // Проверяем, разрешено ли показывать "был в сети"
                    if (user.last_seen) {
                        container.innerHTML = '<span class="user-status status-offline"></span><span>Был(а) ' + formatLastSeen(user.last_seen) + '</span>';
                    } else {
                        container.innerHTML = '<span class="user-status status-offline"></span><span>Был(а) недавно</span>';
                    }
                } else if (user.is_online === true) {
                    container.innerHTML = '<span class="user-status status-online"></span><span>В сети</span>';
                } else {
                    container.innerHTML = '<span class="user-status status-offline"></span><span>Был(а) недавно</span>';
                }
            }

            async function loadUserStatus(userId) {
                try {
                    // Используем API статуса с учетом приватности
                    const response = await fetch(`/api/users/${userId}/status`, {
                        headers: {'Authorization': `Bearer ${accessToken}`}
                    });
                    
                    if (!response.ok) return;
                    
                    const user = await response.json();
                    updateChatHeaderStatus(user);
                    
                } catch (e) {}
            }

            // ========== ИНТЕРВАЛ ОБНОВЛЕНИЯ СТАТУСА (каждые 5 секунд) ==========
            let statusUpdateInterval = null;
            let currentChatPartnerId = null;
            
            function startStatusUpdateInterval() {
                // Очищаем старый интервал если есть
                if (statusUpdateInterval) {
                    clearInterval(statusUpdateInterval);
                }
                
                // Обновляем статус сразу
                if (currentChatPartnerId) {
                    loadUserStatus(currentChatPartnerId);
                }
                
                // Устанавливаем новый интервал на 5 секунд
                statusUpdateInterval = setInterval(() => {
                    if (currentChatPartnerId && currentChatId) {
                        loadUserStatus(currentChatPartnerId);
                    }
                }, 5000);
            }
            
            function stopStatusUpdateInterval() {
                if (statusUpdateInterval) {
                    clearInterval(statusUpdateInterval);
                    statusUpdateInterval = null;
                }
                currentChatPartnerId = null;
            }

            // ========== WEBSOCKET ==========
            function connectWebSocket() {
                if (!accessToken) return;
                
                // Закрываем старый сокет если есть
                if (ws && ws.readyState === WebSocket.OPEN) {
                    ws.close();
                }
                
                ws = new WebSocket(`ws://${window.location.host}/ws?token=${accessToken}`);
                
                ws.onopen = () => {
                    console.log('✅ WebSocket подключен');
                    updateMyStatus(true);
                };
                
                ws.onmessage = (event) => {
                    try {
                        const data = JSON.parse(event.data);
                        
                        if (data.type === 'new_message') {
                            // Только если сообщение в текущем чате - добавляем
                            if (data.message.chat_id === currentChatId) {
                                addMessageToChat(data.message);
                            }
                            // Обновляем список чатов
                            loadChats();
                        }
                        else if (data.type === 'user_status') {
                            // Если это статус собеседника в текущем чате
                            if (currentChatId && currentUser && data.user_id !== currentUser.id) {
                                // Проверяем, что это именно наш собеседник
                                fetch(`/api/chats/${currentChatId}`, {
                                    headers: {'Authorization': `Bearer ${accessToken}`}
                                })
                                .then(r => r.json())
                                .then(chat => {
                                    const otherUser = chat.participants?.find(p => p.id !== currentUser.id);
                                    if (otherUser && otherUser.id === data.user_id) {
                                        // Обновляем статус в заголовке
                                        const container = document.getElementById('chatStatus');
                                        if (container) {
                                            container.innerHTML = '<span class="user-status ' + (data.is_online ? 'status-online' : 'status-offline') + '"></span><span>' + (data.is_online ? 'В сети' : 'Был(а) недавно') + '</span>';
                                        }
                                    }
                                })
                                .catch(() => {});
                            }
                        }
                    } catch (e) {}
                };
                
                ws.onclose = (event) => {
                    console.log('🔌 WebSocket отключен');
                    updateMyStatus(false);
                    
                    // Не переподключаемся если это выход из аккаунта
                    if (!isLoggingOut) {
                        setTimeout(connectWebSocket, 3000);
                    }
                };
                
                ws.onerror = (error) => {
                    console.error('❌ WebSocket ошибка:', error);
                    updateMyStatus(false);
                };
            }

            // ========== ЗАГРУЗКА ЧАТОВ ==========
            async function loadChats() {
                try {
                    const response = await fetch('/api/chats', {
                        headers: {'Authorization': `Bearer ${accessToken}`}
                    });
                    
                    if (!response.ok) return;
                    
                    const chats = await response.json();
                    
                    const chatsList = document.getElementById('chatsList');
                    chatsList.innerHTML = '';
                    
                    chats.forEach(chat => {
                        const isSaved = chat.chat_type === 'saved';
                        let chatName = isSaved ? '⭐ Избранное' : (chat.name || chat.participants?.find(p => p.id !== currentUser?.id)?.username || 'Чат');
                        let avatarText = isSaved ? '⭐' : chatName[0].toUpperCase();
                        
                        const el = document.createElement('div');
                        el.className = `chat-item ${chat.id == currentChatId ? 'active' : ''}`;
                        el.setAttribute('data-chat-id', chat.id);
                        el.setAttribute('data-chat-type', chat.chat_type);
                        el.onclick = () => selectChat(chat.id);
                        
                        el.innerHTML = `
                            <div class="chat-avatar">${avatarText}</div>
                            <div class="chat-info">
                                <div class="chat-name">${chatName}</div>
                                <div class="last-message">${chat.last_message?.content || '...'}</div>
                            </div>
                        `;

                        chatsList.appendChild(el);
                    });
                } catch (e) {}
            }

            // ========== ВЫБОР ЧАТА ==========
            async function selectChat(chatId) {
                currentChatId = chatId;
                localStorage.setItem('currentChatId', chatId);
                
                // Убираем active со всех чатов и добавляем текущему
                document.querySelectorAll('.chat-item').forEach(item => {
                    item.classList.remove('active');
                });
                
                const currentChatItem = document.querySelector(`.chat-item[data-chat-id="${chatId}"]`);
                if (currentChatItem) {
                    currentChatItem.classList.add('active');
                }
                
                try {
                    const chatResponse = await fetch(`/api/chats/${chatId}`, {
                        headers: {'Authorization': `Bearer ${accessToken}`}
                    });
                    
                    if (!chatResponse.ok) return;
                    
                    const chat = await chatResponse.json();
                    
                    // Устанавливаем атрибут для стилизации
                    document.querySelector('.chat-main').setAttribute('data-chat-type', chat.chat_type);
                    
                    const otherUser = chat.participants?.find(p => p.id !== currentUser?.id);
                    
                    if (chat.chat_type === 'saved') {
                        document.getElementById('chatAvatar').textContent = '⭐';
                        document.getElementById('chatName').textContent = '⭐ Избранное';
                        document.getElementById('chatStatus').innerHTML = '<span class="status-text">Ваши сохранённые сообщения</span>';
                    } else {
                        const chatName = chat.name || otherUser?.username || 'Чат';
                        document.getElementById('chatName').textContent = chatName;
                        document.getElementById('chatAvatar').textContent = chatName[0].toUpperCase();
                        
                        if (otherUser) {
                            currentChatPartnerId = otherUser.id;
                            await loadUserStatus(otherUser.id);
                            startStatusUpdateInterval();
                        }
                    }
                    
                    // Загружаем сообщения
                    const messagesResponse = await fetch(`/api/chats/${chatId}/messages`, {
                        headers: {'Authorization': `Bearer ${accessToken}`}
                    });
                    
                    if (!messagesResponse.ok) return;
                    
                    const messages = await messagesResponse.json();
                    
                    const container = document.getElementById('messagesContainer');
                    container.innerHTML = '';
                    
                    messages.forEach(msg => addMessageToChat(msg));
                    
                    container.scrollTop = container.scrollHeight;
                    
                    document.getElementById('messageText').disabled = false;
                    document.getElementById('sendMessageBtn').disabled = false;
                    
                } catch (error) {
                    console.error('Ошибка выбора чата:', error);
                }
            }

            // ========== ДОБАВЛЕНИЕ СООБЩЕНИЯ ==========
            function addMessageToChat(message) {
                const container = document.getElementById('messagesContainer');
                if (!container) return;
                
                const isSent = message.sender_id === currentUser?.id;
                
                const el = document.createElement('div');
                el.className = `message ${isSent ? 'sent' : 'received'}`;
                
                // Если это Избранное и сообщение содержит ключевые слова - добавляем спецкласс
                if (document.querySelector('.chat-main')?.getAttribute('data-chat-type') === 'saved') {
                    if (message.content.includes('ИЗБРАННОЕ') || message.content.includes('⭐')) {
                        el.classList.add('saved-welcome');
                    }
                }
                
                // Форматируем текст: заменяем переносы строк на <br>
                let formattedContent = message.content || '';
                formattedContent = formattedContent.replace(/\\n/g, '<br>');
                
                // МСК timezone +3 hours
                const msgDate = new Date(new Date(message.timestamp).getTime() + (3 * 60 * 60 * 1000));
                const time = msgDate.toLocaleTimeString('ru-RU', {hour: '2-digit', minute: '2-digit'});
                
                el.innerHTML = `<div>${formattedContent}</div><div class="message-info">${time}</div>`;
                
                container.appendChild(el);
                container.scrollTop = container.scrollHeight;
            }

            // ========== ОТПРАВКА СООБЩЕНИЯ ==========
            document.getElementById('sendMessageBtn').onclick = sendMessage;
            document.getElementById('messageText').onkeypress = (e) => {
                if (e.key === 'Enter') sendMessage();
            };

            async function sendMessage() {
                const input = document.getElementById('messageText');
                const content = input.value.trim();
                
                if (!content || !currentChatId) return;
                
                try {
                    const response = await fetch('/api/messages', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `Bearer ${accessToken}`
                        },
                        body: JSON.stringify({content, chat_id: currentChatId})
                    });
                    
                    if (response.ok) {
                        input.value = '';
                        // НЕ добавляем сообщение здесь! WebSocket сам добавит
                    }
                } catch (e) {
                    console.error('Ошибка отправки:', e);
                }
            }

            // ========== ПОИСК ПОЛЬЗОВАТЕЛЕЙ ==========
            let searchTimeout;
            document.getElementById('searchInput').addEventListener('input', function(e) {
                const query = e.target.value.trim();
                
                clearTimeout(searchTimeout);
                
                if (!query) {
                    loadChats();
                    return;
                }
                
                if (query.length < 2) return;
                
                searchTimeout = setTimeout(async () => {
                    try {
                        const response = await fetch(`/api/users/search?q=${encodeURIComponent(query)}`, {
                            headers: {'Authorization': `Bearer ${accessToken}`}
                        });
                        
                        if (!response.ok) return;
                        
                        const users = await response.json();
                        
                        const chatsList = document.getElementById('chatsList');
                        let html = '<div style="padding: 10px; color: #666;">РЕЗУЛЬТАТЫ ПОИСКА:</div>';
                        
                        users.forEach(user => {
                            if (user.id === currentUser?.id) return;
                            
                            html += '<div class="chat-item" onclick="createChatWithUser(' + user.id + ')"><div class="chat-avatar">' + user.username[0].toUpperCase() + '</div><div class="chat-info"><div class="chat-name">' + user.username + '</div><div class="last-message">Нажмите чтобы начать чат</div></div></div>';
                        });
                        
                        chatsList.innerHTML = html;
                        
                    } catch (e) {}
                }, 500);
            });

            // ========== СОЗДАНИЕ ЧАТА ==========
            async function createChatWithUser(userId) {
                try {
                    const response = await fetch('/api/chats', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `Bearer ${accessToken}`
                        },
                        body: JSON.stringify({user_ids: [userId]})
                    });
                    
                    if (!response.ok) {
                        throw new Error('Ошибка создания чата');
                    }
                    
                    const chat = await response.json();
                    
                    document.getElementById('searchInput').value = '';
                    await selectChat(chat.id);
                    await loadChats();
                    
                } catch (error) {
                    console.error('Ошибка:', error);
                    alert('Не удалось создать чат');
                }
            }

            // ========== НАСТРОЙКИ ==========
            window.openSettings = function() {
                const overlay = document.createElement('div');
                overlay.style.cssText = `
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background: rgba(0,0,0,0.5);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    z-index: 10000;
                `;
                
                const modal = document.createElement('div');
                modal.style.cssText = `
                    background: white;
                    border-radius: 20px;
                    width: 90%;
                    max-width: 450px;
                    max-height: 90vh;
                    overflow-y: auto;
                    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                `;
                
                modal.innerHTML = `
                    <div style="padding: 25px;">
                        <h2 style="margin:0 0 20px 0;">⚙️ Настройки</h2>
                        
                        <!-- Переключатель темы -->
                        <div style="margin-bottom: 25px; padding: 15px; background: #f0f2f5; border-radius: 12px;">
                            <div style="display: flex; align-items: center; justify-content: space-between;">
                                <div>
                                    <div style="font-weight: 600; margin-bottom: 4px;">🌙 Тёмная тема</div>
                                    <div style="font-size: 13px; color: #666;" id="themeHint">☀️ Светлая тема</div>
                                </div>
                                
                                <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                                    <input type="checkbox" id="themeToggle" style="width: 20px; height: 20px; cursor: pointer;">
                                    <span id="toggleThemeText">Выкл</span>
                                </label>
                            </div>
                        </div>
                        
                        <!-- Профиль -->
                        <div style="margin-bottom: 25px;">
                            <label style="display: block; margin-bottom: 8px;">Имя</label>
                            <input type="text" id="settingsUsername" value="${currentUser?.username || ''}" style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 10px; margin-bottom: 15px;">
                            
                            <label style="display: block; margin-bottom: 8px;">Email</label>
                            <input type="email" id="settingsEmail" value="${currentUser?.email || ''}" style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 10px; margin-bottom: 15px;">
                            
                            <label style="display: block; margin-bottom: 8px;">О себе</label>
                            <textarea id="settingsBio" rows="3" style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 10px;">${currentUser?.bio || ''}</textarea>
                        </div>
                        
                        <!-- ТУМБЛЕР -->
                        <div style="margin-bottom: 25px; padding: 15px; background: #f0f2f5; border-radius: 12px;">
                            <div style="display: flex; align-items: center; justify-content: space-between;">
                                <div>
                                    <div style="font-weight: 600; margin-bottom: 4px;">👻 Режим невидимки</div>
                                    <div style="font-size: 13px; color: #666;" id="invisibleHint">⚡ Все видят твой статус</div>
                                </div>
                                
                                <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                                    <input type="checkbox" id="invisibleToggle" style="width: 20px; height: 20px; cursor: pointer;">
                                    <span id="toggleStatusText">Выкл</span>
                                </label>
                            </div>
                        </div>
                        
                        <!-- Кнопки -->
                        <div style="display: flex; gap: 10px;">
                            <button onclick="closeSettingsModal()" style="flex:1; padding: 14px; background: #e0e0e0; border: none; border-radius: 10px; cursor: pointer;">Отмена</button>
                            <button onclick="saveSettings()" style="flex:1; padding: 14px; background: linear-gradient(135deg,#667eea,#764ba2); color: white; border: none; border-radius: 10px; cursor: pointer;">Сохранить</button>
                        </div>
                    </div>
                `;
                
                overlay.appendChild(modal);
                document.body.appendChild(overlay);
                
                // Инициализация переключателя темы
                const themeToggle = document.getElementById('themeToggle');
                const themeHint = document.getElementById('themeHint');
                const themeText = document.getElementById('toggleThemeText');
                
                if (themeToggle && themeHint && themeText) {
                    const isDark = localStorage.getItem('theme') === 'dark';
                    themeToggle.checked = isDark;
                    
                    if (isDark) {
                        themeHint.innerHTML = '🌙 Тёмная тема включена';
                        themeText.textContent = 'Вкл';
                    } else {
                        themeHint.innerHTML = '☀️ Светлая тема';
                        themeText.textContent = 'Выкл';
                    }
                    
                    themeToggle.onchange = function() {
                        if (themeToggle.checked) {
                            themeHint.innerHTML = '🌙 Тёмная тема включена';
                            themeText.textContent = 'Вкл';
                        } else {
                            themeHint.innerHTML = '☀️ Светлая тема';
                            themeText.textContent = 'Выкл';
                        }
                    };
                }
                
                // Загружаем состояние из currentUser (не с сервера лишний раз)
                const toggle = document.getElementById('invisibleToggle');
                const hint = document.getElementById('invisibleHint');
                const statusText = document.getElementById('toggleStatusText');
                
                if (toggle && hint && statusText && currentUser) {
                    const isInvisible = !currentUser.show_status && !currentUser.show_last_seen;
                    toggle.checked = isInvisible;
                    
                    if (isInvisible) {
                        hint.innerHTML = '👻 Никто не видит твой онлайн';
                        statusText.textContent = 'Вкл';
                    } else {
                        hint.innerHTML = '⚡ Все видят твой статус';
                        statusText.textContent = 'Выкл';
                    }
                    
                    // Обновляем подсказку при клике
                    toggle.onchange = function() {
                        if (toggle.checked) {
                            hint.innerHTML = '👻 Никто не видит твой онлайн';
                            statusText.textContent = 'Вкл';
                        } else {
                            hint.innerHTML = '⚡ Все видят твой статус';
                            statusText.textContent = 'Выкл';
                        }
                    };
                }
            };

            // Сохранение
            window.saveSettings = async function() {
                const username = document.getElementById('settingsUsername').value.trim();
                const email = document.getElementById('settingsEmail').value.trim();
                const bio = document.getElementById('settingsBio').value.trim();
                const invisibleMode = document.getElementById('invisibleToggle').checked;
                const darkMode = document.getElementById('themeToggle').checked;
                
                if (!username || !email) {
                    alert('❌ Заполни поля');
                    return;
                }
                
                // Сохраняем тему в localStorage
                localStorage.setItem('theme', darkMode ? 'dark' : 'light');
                applyTheme(darkMode);
                
                try {
                    const response = await fetch('/api/users/me', {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `Bearer ${accessToken}`
                        },
                        body: JSON.stringify({
                            username,
                            email,
                            bio,
                            show_status: !invisibleMode,
                            show_last_seen: !invisibleMode
                        })
                    });
                    
                    if (response.ok) {
                        const updatedUser = await response.json();
                        currentUser = updatedUser; // Обновляем currentUser
                        
                        document.getElementById('userName').textContent = updatedUser.username;
                        document.getElementById('userAvatar').textContent = updatedUser.username[0].toUpperCase();
                        
                        // Закрываем окно
                        document.querySelector('[style*="position: fixed;"]').remove();
                        
                        // Простое уведомление
                        const notif = document.createElement('div');
                        notif.style.cssText = 'position:fixed; top:20px; right:20px; background:#2ecc71; color:white; padding:12px 24px; border-radius:8px; z-index:10001;';
                        notif.textContent = invisibleMode ? '👻 Режим невидимки' : '✅ Сохранено';
                        document.body.appendChild(notif);
                        setTimeout(() => notif.remove(), 2000);
                    }
                } catch (e) {
                    alert('❌ Ошибка');
                }
            };

            // Закрытие
            window.closeSettingsModal = function() {
                const overlay = document.querySelector('[style*="position: fixed;"]');
                if (overlay) overlay.remove();
            };

            // ========== УВЕДОМЛЕНИЯ ==========
            function showNotification(message) {
                const notification = document.createElement('div');
                notification.style.cssText = `
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background: white;
                    color: #333;
                    padding: 12px 20px;
                    border-radius: 12px;
                    box-shadow: 0 5px 20px rgba(0,0,0,0.2);
                    z-index: 2000;
                    animation: slideIn 0.3s ease;
                    font-size: 14px;
                    border-left: 4px solid ${message.includes('✅') ? '#2ecc71' : '#ff4757'};
                `;
                notification.textContent = message;
                document.body.appendChild(notification);
                
                setTimeout(() => {
                    notification.style.animation = 'slideOut 0.3s ease';
                    setTimeout(() => notification.remove(), 300);
                }, 3000);
            }
            
            const style = document.createElement('style');
            style.textContent = `
                @keyframes slideIn {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
                @keyframes slideOut {
                    from { transform: translateX(0); opacity: 1; }
                    to { transform: translateX(100%); opacity: 0; }
                }
            `;
            document.head.appendChild(style);
            // ========== ВЫХОД ==========
            let isLoggingOut = false; // Добавь в начало с другими переменными

            window.logout = function() {
                isLoggingOut = true;
                
                // Закрываем WebSocket
                if (ws) {
                    ws.onclose = null; // Убираем обработчик чтобы не переподключался
                    ws.close();
                    ws = null;
                }
                
                // Чистим localStorage
                localStorage.removeItem('accessToken');
                localStorage.removeItem('refreshToken');
                localStorage.removeItem('currentChatId');
                
                // Обнуляем переменные
                accessToken = null;
                refreshToken = null;
                currentUser = null;
                currentChatId = null;
                
                // Показываем форму входа
                document.getElementById('authContainer').style.display = 'block';
                document.getElementById('messengerContainer').style.display = 'none';
                
                // Очищаем поля
                document.getElementById('loginUsername').value = '';
                document.getElementById('loginPassword').value = '';
                document.getElementById('regUsername').value = '';
                document.getElementById('regEmail').value = '';
                document.getElementById('regPassword').value = '';
                document.getElementById('regPasswordConfirm').value = '';
                
                isLoggingOut = false;
            };
        </script>
    </body>
    </html>
    """

# ========== API ПОЛЬЗОВАТЕЛИ ==========
@app.get("/api/users/{user_id}/status")
async def get_user_status(
    user_id: int,
    current_user: models.User = Depends(get_current_user),
    db: AsyncSession = Depends(database.get_db)
):
    """Получить статус пользователя с учетом настроек приватности"""
    result = await db.execute(
        select(models.User).where(models.User.id == user_id)
    )
    user = result.scalar_one_or_none()
    
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Формируем ответ с учетом настроек
    status_response = {
        "user_id": user.id,
        "username": user.username,
        "is_online": False,
        "last_seen": None,
        "status_text": None,
        "custom_status": None
    }
    
    # Если пользователь разрешил показывать статус
    if user.show_status:
        status_response["is_online"] = user.is_online
        status_response["status_text"] = user.status_text
    
    # Если разрешено показывать "был в сети"
    if user.show_last_seen and not user.is_online:
        status_response["last_seen"] = user.last_seen.isoformat() if user.last_seen else None
    
    return status_response

@app.put("/api/users/me/settings")
async def update_user_settings(
    request: Request,
    current_user: models.User = Depends(get_current_user),
    db: AsyncSession = Depends(database.get_db)
):
    """Обновление настроек пользователя"""
    try:
        data = await request.json()
        
        if "show_status" in data:
            current_user.show_status = data["show_status"]
        if "show_last_seen" in data:
            current_user.show_last_seen = data["show_last_seen"]
        if "status_text" in data:
            current_user.status_text = data["status_text"]
        
        await db.commit()
        await db.refresh(current_user)
        
        return {"status": "success", "user": current_user}
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/users/search", response_model=List[schemas.UserResponse])
async def search_users(
    q: str,
    current_user: models.User = Depends(get_current_user),
    db: AsyncSession = Depends(database.get_db)
):
    result = await db.execute(
        select(models.User).where(
            and_(
                models.User.id != current_user.id,
                or_(
                    models.User.username.ilike(f"%{q}%"),
                    models.User.email.ilike(f"%{q}%")
                )
            )
        ).limit(20)
    )
    return result.scalars().all()

@app.get("/api/users/{user_id}", response_model=schemas.UserResponse)
async def get_user(
    user_id: int,
    db: AsyncSession = Depends(database.get_db)
):
    result = await db.execute(
        select(models.User).where(models.User.id == user_id)
    )
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

@app.put("/api/users/me")
async def update_user(
    request: Request,
    current_user: models.User = Depends(get_current_user),
    db: AsyncSession = Depends(database.get_db)
):
    try:
        data = await request.json()
        username = data.get("username")
        email = data.get("email")
        
        if username and username != current_user.username:
            result = await db.execute(
                select(models.User).where(models.User.username == username)
            )
            if result.scalar_one_or_none():
                raise HTTPException(status_code=400, detail="Username already taken")
            current_user.username = username
        
        if email and email != current_user.email:
            result = await db.execute(
                select(models.User).where(models.User.email == email)
            )
            if result.scalar_one_or_none():
                raise HTTPException(status_code=400, detail="Email already registered")
            current_user.email = email
        
        # Исправлено: добавляем обработку настроек приватности
        if "show_status" in data:
            current_user.show_status = data["show_status"]
        if "show_last_seen" in data:
            current_user.show_last_seen = data["show_last_seen"]
        
        await db.commit()
        await db.refresh(current_user)
        return current_user
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ========== API ЧАТЫ ==========
@app.get("/api/chats", response_model=List[schemas.ChatResponse])
async def get_user_chats(
    current_user: models.User = Depends(get_current_user),
    db: AsyncSession = Depends(database.get_db)
):
    await ensure_saved_chat(current_user.id, db)
    
    result = await db.execute(
        select(models.Chat)
        .join(models.Chat.participants)
        .where(models.User.id == current_user.id)
        .options(
            selectinload(models.Chat.participants),
            selectinload(models.Chat.messages).selectinload(models.Message.sender)
        )
        .order_by(
            models.Chat.chat_type == 'saved',
            models.Chat.created_at.desc()
        )
    )
    
    chats = result.scalars().all()
    response_chats = []
    
    for chat in chats:
        messages = sorted(chat.messages, key=lambda m: m.timestamp, reverse=True)
        last_message = messages[0] if messages else None
        
        if chat.chat_type == 'saved':
            chat.name = "⭐ Избранное"
        
        response_chats.append({
            "id": chat.id,
            "name": chat.name,
            "chat_type": chat.chat_type,
            "created_at": chat.created_at,
            "participants": chat.participants,
            "last_message": last_message
        })
    
    return response_chats

@app.get("/api/chats/{chat_id}", response_model=schemas.ChatResponse)
async def get_chat(
    chat_id: int,
    current_user: models.User = Depends(get_current_user),
    db: AsyncSession = Depends(database.get_db)
):
    result = await db.execute(
        select(models.Chat)
        .where(models.Chat.id == chat_id)
        .options(
            selectinload(models.Chat.participants),
            selectinload(models.Chat.messages).selectinload(models.Message.sender)
        )
    )
    chat = result.scalar_one_or_none()
    
    if not chat:
        raise HTTPException(status_code=404, detail="Chat not found")
    
    if current_user not in chat.participants:
        raise HTTPException(status_code=403, detail="Access denied")
    
    return chat

@app.post("/api/chats", response_model=schemas.ChatResponse)
async def create_chat(
    request: Request,
    current_user: models.User = Depends(get_current_user),
    db: AsyncSession = Depends(database.get_db)
):
    try:
        data = await request.json()
        user_ids = data.get("user_ids", [])
        
        if not user_ids:
            raise HTTPException(status_code=400, detail="user_ids is required")
        
        other_user_id = user_ids[0]
        
        # Проверяем существование пользователя
        result = await db.execute(
            select(models.User).where(models.User.id == other_user_id)
        )
        other_user = result.scalar_one_or_none()
        
        if not other_user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Ищем существующий чат между пользователями
        stmt = text("""
        SELECT DISTINCT c.id 
        FROM chats c 
        JOIN chat_participants cp1 ON c.id = cp1.chat_id 
        JOIN chat_participants cp2 ON c.id = cp2.chat_id 
        WHERE c.chat_type = 'private' 
        AND cp1.user_id = :user1 
        AND cp2.user_id = :user2
        """)
        
        result = await db.execute(
            stmt, {"user1": current_user.id, "user2": other_user_id}
        )
        existing_row = result.first()
        
        if existing_row:
            # Чат уже существует - возвращаем его
            existing_chat_id = existing_row[0]
            chat_result = await db.execute(
                select(models.Chat)
                .where(models.Chat.id == existing_chat_id)
                .options(selectinload(models.Chat.participants))
            )
            return chat_result.scalar_one()
        
        # Если чата нет - создаем НОВЫЙ
        chat = models.Chat(
            name=None,
            chat_type="private",
            created_by=current_user.id
        )
        
        db.add(chat)
        await db.flush()
        
        # Добавляем участников
        await db.execute(
            text("INSERT INTO chat_participants (user_id, chat_id) VALUES (:uid, :cid)"),
            {"uid": current_user.id, "cid": chat.id}
        )
        await db.execute(
            text("INSERT INTO chat_participants (user_id, chat_id) VALUES (:uid, :cid)"),
            {"uid": other_user_id, "cid": chat.id}
        )
        
        await db.commit()
        
        # Возвращаем созданный чат
        chat_result = await db.execute(
            select(models.Chat)
            .where(models.Chat.id == chat.id)
            .options(selectinload(models.Chat.participants))
        )
        return chat_result.scalar_one()
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error creating chat: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/chats/{chat_id}/messages", response_model=List[schemas.MessageResponse])
async def get_chat_messages(
    chat_id: int,
    limit: int = 50,
    offset: int = 0,
    current_user: models.User = Depends(get_current_user),
    db: AsyncSession = Depends(database.get_db)
):
    chat_result = await db.execute(
        select(models.Chat)
        .where(models.Chat.id == chat_id)
        .options(selectinload(models.Chat.participants))
    )
    chat = chat_result.scalar_one_or_none()
    
    if not chat or current_user not in chat.participants:
        raise HTTPException(status_code=403, detail="Access denied")
    
    messages_result = await db.execute(
        select(models.Message)
        .where(models.Message.chat_id == chat_id)
        .order_by(desc(models.Message.timestamp))
        .offset(offset)
        .limit(limit)
        .options(selectinload(models.Message.sender))
    )
    
    messages = messages_result.scalars().all()
    
    unread_messages = [m for m in messages if not m.is_read and m.sender_id != current_user.id]
    for msg in unread_messages:
        msg.is_read = True
    await db.commit()
    
    return sorted(messages, key=lambda m: m.timestamp)

# ========== API СООБЩЕНИЯ ==========
@app.post("/api/messages", response_model=schemas.MessageResponse)
async def create_message(
    request: Request,
    current_user: models.User = Depends(get_current_user),
    db: AsyncSession = Depends(database.get_db)
):
    try:
        data = await request.json()
        chat_id = data.get("chat_id")
        content = data.get("content")
        
        if not chat_id or not content:
            raise HTTPException(status_code=400, detail="chat_id and content are required")
        
        chat_result = await db.execute(
            select(models.Chat)
            .where(models.Chat.id == chat_id)
            .options(selectinload(models.Chat.participants))
        )
        chat = chat_result.scalar_one_or_none()
        
        if not chat or current_user not in chat.participants:
            raise HTTPException(status_code=403, detail="Access denied")
        
        message = models.Message(
            content=content,
            sender_id=current_user.id,
            chat_id=chat_id
        )
        
        db.add(message)
        await db.commit()
        await db.refresh(message)
        await db.refresh(message, ['sender'])
        
        ws_message = {
            "type": "new_message",
            "message": {
                "uuid": message.uuid,
                "content": message.content,
                "timestamp": message.timestamp.isoformat(),
                "is_read": message.is_read,
                "is_edited": message.is_edited,
                "is_deleted": message.is_deleted,
                "sender_id": message.sender_id,
                "chat_id": message.chat_id,
                "sender_username": message.sender.username
            }
        }
        
        # Отправляем сообщение всем в чате (включая отправителя)
        await manager.broadcast_to_chat(ws_message, message.chat_id, exclude_user=None)
        
        return message
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error creating message: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/api/messages/{message_uuid}")
async def delete_message(
    message_uuid: str,
    current_user: models.User = Depends(get_current_user),
    db: AsyncSession = Depends(database.get_db)
):
    result = await db.execute(
        select(models.Message).where(models.Message.uuid == message_uuid)
    )
    message = result.scalar_one_or_none()
    
    if not message or message.sender_id != current_user.id:
        raise HTTPException(status_code=403, detail="Cannot delete this message")
    
    message.is_deleted = True
    message.content = "[deleted]"
    await db.commit()
    
    return {"status": "ok"}

# ========== WEBSOCKET ==========
@app.websocket("/ws")
async def websocket_endpoint(
    websocket: WebSocket,
    token: str
):
    try:
        from auth import SECRET_KEY, ALGORITHM
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
        
        if not username:
            await websocket.close(code=1008, reason="Invalid token")
            return
        
        async with AsyncSessionLocal() as db:
            result = await db.execute(
                select(models.User).where(models.User.username == username)
            )
            user = result.scalar_one_or_none()
            
            if not user:
                await websocket.close(code=1008, reason="User not found")
                return
            
            await manager.connect(websocket, user.id)
            
            user.is_online = True
            user.last_seen = datetime.utcnow()
            await db.commit()
            
            try:
                chats_result = await db.execute(
                    select(models.Chat)
                    .join(models.Chat.participants)
                    .where(models.User.id == user.id)
                )
                user_chats = chats_result.scalars().all()
                
                for chat in user_chats:
                    await manager.join_chat(user.id, chat.id)
                
                await websocket.send_json({
                    "type": "connected",
                    "message": "WebSocket connected successfully",
                    "user_id": user.id
                })
                
                while True:
                    await websocket.receive_text()
                    
            except WebSocketDisconnect:
                await manager.disconnect(user.id)
                
                user.is_online = False
                user.last_seen = datetime.utcnow()
                await db.commit()
                
    except Exception as e:
        print(f"WebSocket error: {e}")
        await websocket.close()

# ========== ЗАПУСК ==========
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
